#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc,char *argv[])
{
   
    if(argc<2)
    {
      printf("USAGE : seed <z>");
      return 1;
    }
    int z=atoi(argv[1]);
    if(myseed(z)<0)
    {
      printf("Seed failed\n");
    }
    else
    {
        printf("Seed successfully\n");
    }
    return 0;
}