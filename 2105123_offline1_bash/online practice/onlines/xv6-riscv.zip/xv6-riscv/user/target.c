#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc,char*argv[])
{
    if(argc!=2)
    {
        printf("USAGE: target <charachter>\n");
        return 1;
    }
    if(strlen(argv[1])!=1)
    {   printf("please provide one charachter\n");
        return 1;
    }
    char target =argv[1][0];
    
    if(setTargChar(target)<0)
    {
        printf("Failed to set target charachetr\n");
        return 1;
    }
    printf("Target charachetr is set to %c\n",target);
    

    return 0;
}