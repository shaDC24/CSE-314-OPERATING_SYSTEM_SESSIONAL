#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc,char *argv[])
{
   
    if(argc<4)
    {
      printf("USAGE : sample <k> <len> <array elements>\n");
      return 1;
    }
    int k=atoi(argv[1]);
    int len=atoi(argv[2]);
    struct array a;
    a.len=len;
    for(int i=0;i<a.len;i++)
    {
        int ind=3+i;
        int el=atoi(argv[ind]);
        a.array[i]=el;
    }
    printf("After reading input\n");
    for(int i=0;i<a.len;i++)
    {
        printf("%d  ",a.array[i]);
    }
    sample(&a,k);
    printf("Sampled elements are ");
    for(int i=0;i<k;i++)
    {
        printf("%d ",a.selected[i]);
    }
    printf("\n");

    return 0;
}