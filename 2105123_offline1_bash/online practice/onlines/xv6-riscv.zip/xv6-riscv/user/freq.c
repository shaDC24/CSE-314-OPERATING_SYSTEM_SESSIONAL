#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc,char*argv[])
{
    if(argc!=2)
    {
        printf("USAGE: target <string>\n");
        return 1;
    }

    int count=countTargFreq(argv[1]);
    if(count<0)
    {
        printf("Failed to count target charachetr\n");
        return 1;
    }
    printf("Found %d occurences of target\n",count);
    

    return 0;
}