#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc,char*argv[])
{
    if(argc!=2)
    {
        printf("USAGE: next <n>\n");
        return 1;
    }

    int n=argv[1];
    
    if(getRandomNumbers(n)<0)
    {
        printf("Failed to set target charachetr\n");
        return 1;
    }

    

    return 0;
}