#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


int main(int argc,char*argv[])
{
    printf("From user\n");
   if(argc!=2)
   {
    printf("Provide the string\n");
   }
   struct freq_array a;
   countFreq(argv[1],&a);
   for(int i=0;i<128;i++)
   {
    char c=(char) i;
    char buf[2];
    buf[0]=c;
    buf[1]='\0';
    if(a.counts[i]!=0)
        printf("%s : %d\n",buf,a.counts[i]);
   }
   return 0;

}